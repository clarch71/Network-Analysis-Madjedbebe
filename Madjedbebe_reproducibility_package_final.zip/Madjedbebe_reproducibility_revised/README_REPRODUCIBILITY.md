# Madjedbebe technological-complexity analysis: revised reproducibility package

This package corresponds to the reviewer-revised manuscript **“Measuring Technological Complexity in the Lithic Industries of Northern Australia: A Network-Based Approach.”**

## Contents

- `data/complete_artefact_data.csv` — analysis fields from the complete artefact dataset supplied with the revision. It is a CSV rendering of the legacy Excel dataset, restricted to the original 18 source columns so the analysis does not depend on obsolete BIFF/XLS readers.
- `data/retouch_data.csv` — the retouch/reduction dataset supplied with the revision (`Phase`, `Cortex`, `II`, `RP`, `Kuhn`).
- `run_revised_analysis.py` — single reproducible analysis script.
- `outputs/` — expected outputs from the script.
- `figures/` — revised manuscript figures generated for the resubmission.

## Run

Python 3.10+ is recommended. From this directory:

```bash
python -m pip install -r requirements.txt
python run_revised_analysis.py
```

The script writes/overwrites CSV files in `outputs/`.

## Primary network definition

For each archaeological phase (2–7), the primary bipartite network links **tool classes** (`TYPOLOGY` where recorded, otherwise `TYPE`) to the **fine-grained raw-material categories** in `RMTYPE`. An edge records at least one observed tool–raw-material association. Bipartite density is observed edges divided by the number of possible tool × raw-material edges.

The tool one-mode projection links two tool classes when they share at least one raw material. Projection density, degree summaries, and the clustering coefficient are descriptive. **Clustering is the unweighted average clustering coefficient of the one-mode tool projection; it is not bipartite clustering and is not tested against the permutation null.**

## Null model

There is one inferential null model for the primary tool–raw-material network. Within each phase:

1. tool labels remain fixed;
2. the vector of raw-material labels is randomly permuted among artefacts;
3. therefore the observed phase-specific frequencies (marginal distributions) of tool classes and raw materials are both preserved, while their pairing is randomised;
4. the number of realised tool–raw-material associations is recalculated.

The analysis uses **10,000 permutations per phase**. The RNG seed is `20260818 + phase` (20260820–20260825 for Phases 2–7). For a statistic `S`, Monte Carlo tail probabilities use the +1 correction:

`p_lower = (#{S_perm <= S_obs} + 1)/(N_perm + 1)`

`p_upper = (#{S_perm >= S_obs} + 1)/(N_perm + 1)`

and the reported two-sided probability is `min(1, 2 × min(p_lower, p_upper))`.

Because the possible number of tool–raw-material links is fixed within a phase, tests of realised edge count and bipartite density are equivalent. Degree distributions and clustering are reported descriptively, not as null-model tests.

## Reduction-intensity index

The reduction analysis uses the separate retouch dataset. `II`, `RP`, and `Kuhn` (GIUR) are independently min–max normalised across the full retouch dataset. The artefact-level composite reduction-intensity index is the **unweighted arithmetic mean of the available normalised II, RP, and GIUR values**. Phase values are means across artefacts in that phase.

Overall phase differences are tested with Kruskal–Wallis. Pairwise contrasts use two-sided asymptotic Mann–Whitney U tests with Bonferroni correction across all 15 phase pairs. Effect size is `r = |z|/sqrt(n1+n2)`, with `|z|` taken from the standard-normal deviate corresponding to the two-sided asymptotic p-value.

## SDI

Scar Density Index (SDI) is treated as a core-specific descriptive variable and is not part of the composite reduction index. There are 146 records classified as cores/core fragments in Phases 2–7, of which **132 contain positive usable SDI values** (Phase Ns: 29, 24, 41, 16, 12, 10). One non-core record carrying a positive SDI value is excluded from the core-specific summary.

## Changes relative to the earlier archive

The earlier manuscript text described two random-network null models, but the deposited analysis implemented a within-phase raw-material-label permutation. The revision aligns the manuscript and code to the model actually supported by the supplied artefact data and makes the permutation count, seed, and p-value definition explicit and consistent. The retouch dataset supplied with the revision is now the authoritative input for reduction-intensity statistics.
