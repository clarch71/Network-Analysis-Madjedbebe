# Citation guidance

When using this archive, cite the associated manuscript/article:

**“Measuring Technological Complexity in the Lithic Industries of Northern Australia: A Network-Based Approach.”**

Use the final published author list, journal, year, volume/pages or article number, and DOI once these are assigned by the journal.

For repository deposition, the archive may additionally be cited as:

**Madjedbebe technological-complexity analysis: reproducibility package. Version 1.0.0 (19 August 2026).**

Add the repository DOI or persistent identifier after deposition.

This file intentionally does not invent a journal DOI or repository DOI before one has been assigned.
