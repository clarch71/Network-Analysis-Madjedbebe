# Data dictionary

This dictionary documents the fields present in the two deposited CSV inputs and, critically, how the reproducibility script uses them. Legacy fields not used in the deposited analyses are identified explicitly rather than being assigned undocumented analytical meaning.

## `data/complete_artefact_data.csv`

| Field | Description | Type / values | Used in deposited analysis? |
|---|---|---|---|
| `TYPE` | Broad lithic/artefact class recorded in the source dataset. | Categorical; e.g. Flake, Core, Bipolar Core, Retouched Flake. | **Yes.** Used as fallback tool class when `TYPOLOGY` is blank; also used in core identification for the SDI summary. |
| `RMTYPE` | Fine-grained raw-material classification. | Categorical; 30 recorded categories in this extract. | **Yes.** Raw-material node category in the primary bipartite network. |
| `PLATPREP` | Platform-preparation category recorded in the source dataset. | Categorical; e.g. Faceting, Overhang Removal, Both. | No. Retained as a legacy source field. |
| `PLATTYPE` | Striking-platform type/category recorded in the source dataset. | Categorical. | No. Retained as a legacy source field. |
| `TERMINAT` | Flake termination category recorded in the source dataset. | Categorical; e.g. Feather, Hinge, Step, Outrepasse. | No. Retained as a legacy source field. |
| `TYPOLOGY` | More specific technological/typological classification where assigned. | Categorical; blank for many records. | **Yes.** Preferred tool-class label; `TYPE` is used when this field is blank. |
| `Square` | Excavation square provenance. | Categorical/alphanumeric. | No direct statistical role in this script. |
| `Spit` | Excavation spit provenance. | Categorical/numeric as supplied. | No direct statistical role in this script. |
| `Phase` | Archaeological phase assignment. | Integer phase code. | **Yes.** Analyses are restricted to Phases 2–7 and calculated by phase. |
| `Marginal Angle` | Legacy numeric marginal-angle measure as supplied in the source extract. | Numeric; measurement protocol/units are not required by or encoded in this reproducibility analysis. | No. |
| `Invasiveness Index` | Artefact-level invasiveness-index field retained from the complete source extract. | Numeric, observed 0–1 in measured records. | No. The reduction analysis uses `II` from `retouch_data.csv` instead. |
| `Retouch Perimeter` | Artefact-level retouch-perimeter field retained from the complete source extract. | Numeric, observed 0–1 in measured records. | No. The reduction analysis uses `RP` from `retouch_data.csv` instead. |
| `Retouched Edge Curvture` | Legacy retouched-edge curvature metric. The misspelling `Curvture` is preserved from the source column name. | Numeric as supplied. | No. |
| `Kuhn Index` | Kuhn/Geometric Index of Unifacial Reduction (GIUR) field retained from the complete source extract. | Numeric; zero occurs widely in the legacy extract. | No. The reduction analysis uses `Kuhn` from `retouch_data.csv` instead. |
| `Retouch Edge Anlge` | Legacy retouch-edge angle measure. The misspelling `Anlge` is preserved from the source column name. | Numeric as supplied. | No. |
| `elongation` | Legacy elongation metric as supplied in the source extract. | Numeric, dimensionless metric as deposited. | No. |
| `Surface area` | Legacy surface-area field as supplied in the source extract. | Numeric; measurement units are not encoded in the CSV. | No. |
| `SDI` | Scar Density Index. | Numeric. | **Yes.** Used only for the core-specific descriptive SDI summary; values must be >0 to enter the usable SDI subset. |

### Derived field used by the script

`TOOL_CLASS` is **not** stored in the CSV. It is constructed at runtime as:

`TOOL_CLASS = TYPOLOGY if TYPOLOGY is present, otherwise TYPE`

## `data/retouch_data.csv`

| Field | Description | Type / values | Used in deposited analysis? |
|---|---|---|---|
| `Phase` | Archaeological phase assignment. | Numeric phase code; Phase 1 is present in the source file, but the analysis restricts to Phases 2–7. | **Yes.** |
| `Cortex` | Cortex percentage/category as supplied in the retouch dataset. | Numeric percentage values from 0 to 100. | No. Retained in the authoritative retouch input but not used by the reduction-index script. |
| `II` | Invasiveness Index used as a reduction-intensity proxy. | Numeric; missing allowed. | **Yes.** Independently min–max normalised within the Phase 2–7 analysis subset. |
| `RP` | Retouch Perimeter used as a reduction-intensity proxy. | Numeric; missing allowed. | **Yes.** Independently min–max normalised within the Phase 2–7 analysis subset. |
| `Kuhn` | Kuhn / GIUR reduction index used as a reduction-intensity proxy. | Numeric; missing allowed. | **Yes.** Independently min–max normalised within the Phase 2–7 analysis subset. |

### Composite reduction-intensity index

For each Phase 2–7 row, the script computes:

1. independent min–max normalisation of `II`, `RP`, and `Kuhn` across the Phase 2–7 analysis subset;
2. the unweighted arithmetic mean of the normalised components available for that row;
3. exclusion only when all three components are missing.

No missing component is imputed.
