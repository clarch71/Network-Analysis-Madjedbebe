# Computational environment

## Minimum requirements

The workflow is written for Python 3 and the package declares Python 3.10+ as the recommended minimum. Minimum library requirements are listed in `requirements.txt`.

## Final validation environment

The archive was validated on 19 August 2026 with:

- Python 3.13.5
- pandas 2.2.3
- NumPy 2.3.5
- SciPy 1.17.0
- NetworkX 3.6.1

These versions are pinned in `requirements-lock.txt`.

## Reproduction test

The final validation test removed the generated CSV outputs, reran `python run_revised_analysis.py` from the package root, and compared all regenerated CSVs against the deposited reference outputs. In the pinned validation environment all eight regenerated outputs were byte-for-byte identical to the reference outputs.

The randomisation analysis is deterministic because each phase uses a fixed NumPy random-number-generator seed defined in the script (`20260818 + phase`).

## Portability

All data and output paths are resolved relative to the location of `run_revised_analysis.py`, so the analysis does not depend on the user's current working directory or on machine-specific absolute paths.
