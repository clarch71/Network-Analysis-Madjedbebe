# Licence and reuse

## Analysis code

The original analysis code in `run_revised_analysis.py` and the convenience launcher are released under the MIT License:

Copyright (c) 2026 the authors of the associated manuscript

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

## Data, figures, and manuscript-derived content

No additional open licence for the deposited archaeological data, figure files, or manuscript-derived content is granted by this archive itself. Their reuse is subject to the terms applied by the final repository/journal deposit and to any applicable project, heritage, community, cultural, or third-party permissions.

This distinction is intentional: it makes the software licence explicit without presuming authority to apply a permissive licence to archaeological data or figure content that may be governed by additional permissions.
