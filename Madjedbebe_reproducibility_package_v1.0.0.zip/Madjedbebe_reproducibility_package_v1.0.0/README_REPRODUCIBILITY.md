# Reproducibility documentation

The canonical package documentation is now `README.md` in the archive root. It defines the reproducible scope, workflow, statistical methods, expected outputs, software environment, data limitations, and figure status.
