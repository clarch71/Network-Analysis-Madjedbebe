# Data files

## `complete_artefact_data.csv`

This file is a CSV rendering of the 18 analysis fields retained from the legacy complete artefact spreadsheet supplied for the manuscript revision. It contains 2,566 rows and is used for the tool–raw-material network analysis and the core-specific SDI summary.

The script restricts analysis to Phases 2–7. `TOOL_CLASS` is constructed internally as `TYPOLOGY` where that field is present and nonblank, otherwise `TYPE`. Network rows missing either the resulting `TOOL_CLASS` or `RMTYPE` are excluded from the network calculation for that phase.

The legacy file contains fields that are not used by the deposited analyses. They are retained to preserve the supplied analysis extract. See `../DATA_DICTIONARY.md`.

## `retouch_data.csv`

This file contains 2,577 rows and five fields: `Phase`, `Cortex`, `II`, `RP`, and `Kuhn`. It is the authoritative input for the deposited reduction-intensity analysis.

The script restricts the file to Phases 2–7, independently min–max normalises II, RP and Kuhn within that subset, and takes the unweighted row mean of the available normalised values. A row with all three reduction variables missing is excluded from the reduction analysis.

### Row identification limitation

This derived CSV does **not** contain an original archaeological artefact/specimen identifier. Consequently, records that have identical values in all five deposited fields cannot be distinguished by specimen ID in this archive. The analysis treats each row as an independent input record, exactly as deposited. No synthetic identifier has been added because it would provide row addressability but would not restore original archaeological provenance.

This limitation does not alter the phase-level statistics reproduced by `run_revised_analysis.py`, but users wishing to link individual retouch observations back to the master artefact register should use the original project database or coding records where the original identifiers are retained.

## Missing and zero values

- Blank/NA values are treated as missing.
- In the network analysis, records lacking tool class or raw material are excluded from that phase's network.
- In the reduction analysis, zero is a valid numerical value if present; missing values are not imputed.
- For the core-specific SDI summary, only positive SDI values are treated as usable measured SDI values, following the deposited script.
