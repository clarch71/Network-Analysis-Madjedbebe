@echo off
python run_revised_analysis.py
pause
