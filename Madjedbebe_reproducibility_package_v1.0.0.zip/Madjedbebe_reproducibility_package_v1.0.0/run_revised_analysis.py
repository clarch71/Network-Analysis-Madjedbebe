#!/usr/bin/env python3
"""Reproduce the phase-level analyses used in the revised Madjedbebe network manuscript.

Primary network: TOOL_CLASS x fine-grained RMTYPE, by Phase 2-7.
Null model: within each phase, raw-material labels are permuted among artefacts while
             tool labels are held fixed. This preserves the observed marginal
             frequency distributions of both tool classes and raw materials.
Reduction index: unweighted mean of available min-max normalized II, RP, and GIUR (Kuhn) within the Phase 2-7 analysis subset.

Outputs are written to ./outputs relative to this script.
"""
from pathlib import Path
import pandas as pd
import numpy as np
import networkx as nx
from scipy.stats import kruskal, mannwhitneyu, norm, pearsonr

HERE=Path(__file__).resolve().parent
DATA=HERE/'data'
OUT=HERE/'outputs'
OUT.mkdir(exist_ok=True)
PHASES=[2,3,4,5,6,7]
N_PERM=10000
SEED_BASE=20260818

def clean_str(s):
    s=s.copy()
    s=s.where(~s.isna(), np.nan)
    return s

def prepare_artefacts(df):
    df=df.copy()
    df['Phase']=pd.to_numeric(df['Phase'], errors='coerce')
    df=df[df['Phase'].isin(PHASES)].copy()
    for c in ['TYPE','RMTYPE','TYPOLOGY']:
        df[c]=df[c].astype('string').str.strip()
        df.loc[df[c].isin(['','nan','NaN','None','<NA>']),c]=pd.NA
    df['TOOL_CLASS']=df['TYPOLOGY'].fillna(df['TYPE'])
    return df

def network_metrics(df):
    rows=[]
    for ph in PHASES:
        g=df[df.Phase==ph].dropna(subset=['TOOL_CLASS','RMTYPE']).copy()
        tab=pd.crosstab(g['TOOL_CLASS'], g['RMTYPE'])
        tools=list(tab.index); raws=list(tab.columns)
        edges=int((tab>0).to_numpy().sum())
        poss=len(tools)*len(raws)
        B=nx.Graph()
        tnodes=[f'T::{x}' for x in tools]; rnodes=[f'R::{x}' for x in raws]
        B.add_nodes_from(tnodes,bipartite=0); B.add_nodes_from(rnodes,bipartite=1)
        for ti,t in enumerate(tools):
            for ri,r in enumerate(raws):
                w=int(tab.iat[ti,ri])
                if w>0: B.add_edge(f'T::{t}',f'R::{r}',weight=w)
        # One-mode tool projection; unweighted graph for density/degree/clustering.
        T=nx.bipartite.projected_graph(B, tnodes)
        proj_edges=T.number_of_edges()
        proj_possible=len(tnodes)*(len(tnodes)-1)/2
        proj_density=(proj_edges/proj_possible) if proj_possible else np.nan
        degrees=np.array([d for _,d in T.degree()], dtype=float)
        clustering=nx.average_clustering(T, weight=None) if len(T)>0 else np.nan
        bdegs=np.array([d for _,d in B.degree()],dtype=float)
        rows.append({
            'Phase':ph,'N_artefacts_used':len(g),'Tool_nodes':len(tools),'Raw_material_nodes':len(raws),
            'Observed_bipartite_edges':edges,'Possible_bipartite_edges':poss,
            'Bipartite_density':edges/poss if poss else np.nan,
            'Tool_projection_edges':proj_edges,'Tool_projection_density':proj_density,
            'Bipartite_mean_degree':bdegs.mean() if len(bdegs) else np.nan,
            'Projection_mean_degree':degrees.mean() if len(degrees) else np.nan,
            'Projection_degree_variance':degrees.var(ddof=0) if len(degrees) else np.nan,
            'Projection_clustering_unweighted':clustering
        })
    return pd.DataFrame(rows)

def null_model(df):
    rows=[]
    for ph in PHASES:
        g=df[df.Phase==ph].dropna(subset=['TOOL_CLASS','RMTYPE']).copy()
        tool=g['TOOL_CLASS'].astype(str).to_numpy()
        raw=g['RMTYPE'].astype(str).to_numpy()
        tools=np.unique(tool); raws=np.unique(raw)
        possible=len(tools)*len(raws)
        obs=len(set(zip(tool,raw)))
        seed=SEED_BASE+ph
        rng=np.random.default_rng(seed)
        sims=np.empty(N_PERM,dtype=int)
        for i in range(N_PERM):
            perm=rng.permutation(raw)
            sims[i]=len(set(zip(tool,perm)))
        # +1 Monte Carlo correction. Two-sided p doubles the smaller empirical tail.
        p_lower=(np.count_nonzero(sims<=obs)+1)/(N_PERM+1)
        p_upper=(np.count_nonzero(sims>=obs)+1)/(N_PERM+1)
        p_two=min(1.0,2*min(p_lower,p_upper))
        rows.append({
            'Phase':ph,'N_artefacts_used':len(g),'Observed_edges':obs,'Possible_edges':possible,
            'Observed_density':obs/possible,'Null_mean_edges':sims.mean(),'Null_SD_edges':sims.std(ddof=1),
            'Null_mean_density':sims.mean()/possible,'Z_descriptive':(obs-sims.mean())/sims.std(ddof=1),
            'P_lower':p_lower,'P_upper':p_upper,'P_two_sided':p_two,
            'N_permutations':N_PERM,'RNG_seed':seed
        })
    return pd.DataFrame(rows)

def reduction_analysis(ret):
    ret=ret.copy()
    ret['Phase']=pd.to_numeric(ret['Phase'],errors='coerce')
    ret=ret[ret.Phase.isin(PHASES)].copy()
    for c in ['II','RP','Kuhn']:
        ret[c]=pd.to_numeric(ret[c],errors='coerce')
        mn=ret[c].min(skipna=True); mx=ret[c].max(skipna=True)
        ret[c+'_norm']=(ret[c]-mn)/(mx-mn)
    # unweighted row mean of available normalized components
    ret['Composite_reduction']=ret[['II_norm','RP_norm','Kuhn_norm']].mean(axis=1, skipna=True)
    red=ret.dropna(subset=['Composite_reduction']).copy()
    sumrows=[]
    for ph in PHASES:
        g=red[red.Phase==ph]
        sumrows.append({'Phase':ph,'N':len(g),'Mean_reduction':g.Composite_reduction.mean(),
                        'Median_reduction':g.Composite_reduction.median(),'SD_reduction':g.Composite_reduction.std(ddof=1),
                        'Mean_II':g.II.mean(),'Mean_RP':g.RP.mean(),'Mean_GIUR':g.Kuhn.mean()})
    summary=pd.DataFrame(sumrows)
    groups=[red.loc[red.Phase==ph,'Composite_reduction'].to_numpy() for ph in PHASES]
    H,p=kruskal(*groups)
    kw=pd.DataFrame([{'Kruskal_Wallis_H':H,'df':len(PHASES)-1,'P_value':p}])
    pairs=[]
    m=len(PHASES)*(len(PHASES)-1)//2
    for i,p1 in enumerate(PHASES):
        for p2 in PHASES[i+1:]:
            a=red.loc[red.Phase==p1,'Composite_reduction'].to_numpy()
            b=red.loc[red.Phase==p2,'Composite_reduction'].to_numpy()
            res=mannwhitneyu(a,b,alternative='two-sided',method='asymptotic')
            rawp=float(res.pvalue); adj=min(1.0,rawp*m)
            zabs=float(norm.isf(rawp/2)) if rawp>0 else np.inf
            r=zabs/np.sqrt(len(a)+len(b))
            pairs.append({'Phase_1':p1,'Phase_2':p2,'n_1':len(a),'n_2':len(b),'U':float(res.statistic),
                          'P_raw':rawp,'P_Bonferroni':adj,'Effect_size_r':r})
    return red,summary,kw,pd.DataFrame(pairs)

def sdi_summary(arte):
    a=arte.copy()
    a['Phase']=pd.to_numeric(a.Phase,errors='coerce')
    a['SDI']=pd.to_numeric(a.SDI,errors='coerce')
    tool=a['TYPOLOGY'].astype('string').str.strip().fillna(a['TYPE'].astype('string').str.strip())
    iscore=tool.str.contains('core',case=False,na=False) | a['TYPE'].astype('string').str.contains('core',case=False,na=False)
    cores=a[iscore & a.Phase.isin(PHASES)].copy()
    # Positive SDI values are treated as measured; zero/missing values are not included in core-specific mean SDI.
    usable=cores[cores.SDI>0].copy()
    rows=[]
    for ph in PHASES:
        allc=cores[cores.Phase==ph]; g=usable[usable.Phase==ph]
        rows.append({'Phase':ph,'Core_classified_N':len(allc),'Usable_SDI_N':len(g),'Mean_SDI':g.SDI.mean(),
                     'Median_SDI':g.SDI.median(),'SD_SDI':g.SDI.std(ddof=1)})
    return pd.DataFrame(rows)

def composite_indices(net,redsum):
    x=net[['Phase','Tool_nodes','Raw_material_nodes','Bipartite_density','Tool_projection_density']].merge(
        redsum[['Phase','Mean_reduction']],on='Phase')
    comps=['Tool_nodes','Raw_material_nodes','Bipartite_density','Tool_projection_density','Mean_reduction']
    for c in comps:
        x[c+'_norm']=(x[c]-x[c].min())/(x[c].max()-x[c].min())
    x['Diversity_investment_index']=x[['Tool_nodes_norm','Raw_material_nodes_norm','Mean_reduction_norm']].mean(axis=1)
    x['Network_integrated_complexity_index']=x[[c+'_norm' for c in comps]].mean(axis=1)
    return x

def main():
    arte=prepare_artefacts(pd.read_csv(DATA/'complete_artefact_data.csv'))
    ret=pd.read_csv(DATA/'retouch_data.csv')
    net=network_metrics(arte)
    null=null_model(arte)
    red,redsum,kw,pairs=reduction_analysis(ret)
    sdi=sdi_summary(arte)
    comp=composite_indices(net,redsum)
    net.to_csv(OUT/'network_metrics.csv',index=False)
    null.to_csv(OUT/'null_model_primary.csv',index=False)
    redsum.to_csv(OUT/'reduction_summary.csv',index=False)
    kw.to_csv(OUT/'reduction_kruskal_wallis.csv',index=False)
    pairs.to_csv(OUT/'pairwise_mannwhitney.csv',index=False)
    sdi.to_csv(OUT/'sdi_core_summary.csv',index=False)
    comp.to_csv(OUT/'composite_indices.csv',index=False)
    r1,p1=pearsonr(net.Tool_nodes,net.Tool_projection_edges)
    total_nodes=net.Tool_nodes+net.Raw_material_nodes
    r2,p2=pearsonr(total_nodes,net.Observed_bipartite_edges)
    pd.DataFrame([
      {'Comparison':'tool nodes vs tool-projection edges','Pearson_r':r1,'P_value':p1},
      {'Comparison':'total bipartite nodes vs observed bipartite edges','Pearson_r':r2,'P_value':p2}
    ]).to_csv(OUT/'network_richness_correlations.csv',index=False)
    print('Reproduction complete:', OUT)
    print(net[['Phase','Tool_nodes','Raw_material_nodes','Observed_bipartite_edges','Bipartite_density']].to_string(index=False))
    print(kw.to_string(index=False))

if __name__=='__main__': main()
