#!/usr/bin/env python3
"""Verify SHA-256 hashes recorded in MANIFEST.sha256.

Run from any directory with:
    python /path/to/verify_package.py

For a full computational check, first run run_revised_analysis.py in the pinned
validation environment and then run this verifier. If the regenerated outputs are
byte-identical to the deposited references, the manifest check will pass.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
MANIFEST = HERE / "MANIFEST.sha256"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    if not MANIFEST.exists():
        print(f"ERROR: missing manifest: {MANIFEST}")
        return 2

    failures = 0
    checked = 0
    for raw in MANIFEST.read_text(encoding="utf-8").splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        expected, rel = raw.split("  ", 1)
        path = HERE / rel
        checked += 1
        if not path.is_file():
            print(f"MISSING  {rel}")
            failures += 1
            continue
        actual = sha256(path)
        if actual == expected:
            print(f"PASS     {rel}")
        else:
            print(f"FAIL     {rel}")
            print(f"         expected {expected}")
            print(f"         actual   {actual}")
            failures += 1

    print(f"\nChecked {checked} files; failures: {failures}")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
