@echo off
python run_complete_artefact_network_analysis.py
pause
