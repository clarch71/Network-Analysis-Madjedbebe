import os, re, math, itertools, zipfile, json
from collections import Counter, defaultdict
import numpy as np
import pandas as pd
import networkx as nx
from scipy import stats
import matplotlib.pyplot as plt

INPUT='/mnt/data/Complete artefact data(1).XLS'
OUT='/mnt/data/complete_artefact_network_results'
os.makedirs(OUT, exist_ok=True)
FIG=os.path.join(OUT,'figures'); os.makedirs(FIG, exist_ok=True)
MATS=os.path.join(OUT,'adjacency_matrices'); os.makedirs(MATS, exist_ok=True)
EDGES=os.path.join(OUT,'edge_tables'); os.makedirs(EDGES, exist_ok=True)

# ---------- data cleaning ----------
def clean_text(x):
    if pd.isna(x): return np.nan
    s=str(x).strip()
    if s=='' or s.lower() in ['nan','none']: return np.nan
    s=re.sub(r'\s+',' ',s)
    fixes={
        'flake':'Flake','step':'Step','crushed':'Crushed','feather':'Feather',
        '3Both':'Both','hHertzian':'Hertzian',
        'Quartzite with purple stripes':'Quartzite with Purple Stripes',
        'Retouched Redirection Flake':'Retouched Redirecting Flake',
        'Redirecting Retouched Flake':'Retouched Redirecting Flake',
    }
    return fixes.get(s,s)

def rm_group(r):
    if pd.isna(r): return np.nan
    s=str(r).lower()
    if 'quartzite' in s: return 'Quartzite'
    if 'quartz' in s or 'rock crystal' in s: return 'Quartz'
    if 'silcrete' in s: return 'Silcrete'
    if 'chert' in s or 'chalcedony' in s: return 'Chert/chalcedony'
    if 'dolerite' in s or 'volcanic' in s or 'basalt' in s: return 'Dolerite/volcanic'
    if 'sandstone' in s: return 'Sandstone'
    if 'tuff' in s or 'mudstone' in s: return 'Tuff/mudstone'
    if 'fgs' in s: return 'Fine-grained stone'
    if 'glass' in s: return 'Glass'
    return 'Other/unknown lithology'

def shannon_entropy(counts):
    counts=np.array([c for c in counts if c>0], dtype=float)
    if counts.size==0: return 0.0
    p=counts/counts.sum()
    return float(-(p*np.log(p)).sum())

def clean_df(path):
    df=pd.read_excel(path, sheet_name=0)
    for col in ['TYPE','RMTYPE','PLATPREP','PLATTYPE','TERMINAT','TYPOLOGY','Square']:
        if col in df.columns:
            df[col]=df[col].apply(clean_text)
    df=df.dropna(subset=['Phase']).copy()
    df['Phase']=df['Phase'].astype(int)
    df=df[df['Phase'].between(2,7)].copy()
    df['RM_GROUP']=df['RMTYPE'].apply(rm_group)
    df['TOOL_CLASS']=df['TYPOLOGY'].where(df['TYPOLOGY'].notna(), df['TYPE'])
    df['TYPE_BROAD']=df['TYPE']
    # Treat platform-type code 95 as missing/undetermined, rather than a real technological state.
    df['PLATTYPE_CLEAN']=df['PLATTYPE'].replace({'95': np.nan, 95: np.nan})
    # numeric cols
    num_cols=['Marginal Angle','Invasiveness Index','Retouch Perimeter','Retouched Edge Curvture','Kuhn Index','Retouch Edge Anlge','elongation','Surface area','SDI']
    for c in num_cols:
        if c in df.columns:
            df[c]=pd.to_numeric(df[c], errors='coerce')
    # artefact-level reduction composite: non-retouched pieces treated as zero on retouch measures.
    for c in ['Invasiveness Index','Retouch Perimeter','Kuhn Index']:
        df[c+'_filled']=df[c].fillna(0)
    norm_cols=[]
    for c in ['Invasiveness Index_filled','Retouch Perimeter_filled','Kuhn Index_filled']:
        mn, mx=df[c].min(), df[c].max()
        nc=c.replace('_filled','_norm')
        df[nc]=(df[c]-mn)/(mx-mn) if mx>mn else 0
        norm_cols.append(nc)
    df['REDUCTION_COMP_ALL']=df[norm_cols].mean(axis=1)
    ret_vals=df.loc[df['REDUCTION_COMP_ALL']>0,'REDUCTION_COMP_ALL']
    q1,q2=ret_vals.quantile([1/3,2/3]) if len(ret_vals)>0 else (0,0)
    def red_bin(v):
        if pd.isna(v) or v<=0: return 'None'
        if v<=q1: return 'Low'
        if v<=q2: return 'Moderate'
        return 'High'
    df['REDUCTION_BIN']=df['REDUCTION_COMP_ALL'].apply(red_bin)
    df['REDUCTION_BIN_NONNONE']=df['REDUCTION_BIN'].replace({'None':np.nan})
    df['SDI_filled']=df['SDI'].fillna(0)
    sdi_nonzero=df.loc[df['SDI_filled']>0,'SDI_filled']
    s1,s2=sdi_nonzero.quantile([1/3,2/3]) if len(sdi_nonzero)>0 else (0,0)
    def sdi_bin(v):
        if pd.isna(v) or v<=0: return 'None'
        if v<=s1: return 'Low'
        if v<=s2: return 'Moderate'
        return 'High'
    df['SDI_BIN']=df['SDI_filled'].apply(sdi_bin)
    df['SDI_BIN_NONNONE']=df['SDI_BIN'].replace({'None':np.nan})
    # profile strings for individual artefact technological profiles.
    profile_cols=['TOOL_CLASS','RM_GROUP','PLATPREP','PLATTYPE_CLEAN','TERMINAT','REDUCTION_BIN']
    for c in profile_cols:
        df[c+'_PROFILE']=df[c].fillna('Unrecorded')
    df['ARTEFACT_PROFILE']=df[[c+'_PROFILE' for c in profile_cols]].agg('|'.join, axis=1)
    return df

df=clean_df(INPUT)
df.to_csv(os.path.join(OUT,'cleaned_complete_artefact_data.csv'), index=False)

# ---------- bipartite network ----------
def bipartite_metrics(dat, tool_col='TOOL_CLASS', rm_col='RM_GROUP', phase_col='Phase', n_null=1000, seed=42, prefix='toolclass_rmgroup'):
    rng=np.random.default_rng(seed)
    rows=[]; null_rows=[]
    for ph, g in dat.dropna(subset=[tool_col,rm_col]).groupby(phase_col):
        ct=g.groupby([tool_col,rm_col]).size().unstack(fill_value=0)
        ct.to_csv(os.path.join(MATS,f'{prefix}_phase_{int(ph)}_adjacency.csv'))
        tools=list(ct.index); rms=list(ct.columns)
        tn=len(tools); rn=len(rms); n=int(ct.values.sum())
        obs=int((ct.values>0).sum()); poss=tn*rn; dens=obs/poss if poss else np.nan
        counts=ct.values[ct.values>0].ravel()
        ent=shannon_entropy(counts); even=ent/math.log(obs) if obs>1 else np.nan
        tool_deg=(ct.values>0).sum(axis=1); rm_deg=(ct.values>0).sum(axis=0)
        tool_strength=ct.values.sum(axis=1); rm_strength=ct.values.sum(axis=0)
        B=nx.Graph()
        Tnodes=['T:'+str(t) for t in tools]
        Rnodes=['R:'+str(r) for r in rms]
        B.add_nodes_from(Tnodes, bipartite=0); B.add_nodes_from(Rnodes, bipartite=1)
        for t in tools:
            for r in rms:
                w=int(ct.loc[t,r])
                if w>0: B.add_edge('T:'+str(t),'R:'+str(r), weight=w)
        Tproj=nx.bipartite.weighted_projected_graph(B,Tnodes)
        proj_edges=Tproj.number_of_edges(); proj_poss=tn*(tn-1)/2
        proj_dens=proj_edges/proj_poss if proj_poss else np.nan
        avg_clust=nx.average_clustering(Tproj) if Tproj.number_of_nodes()>1 else np.nan
        edge_table=[]
        for t in tools:
            for r in rms:
                w=int(ct.loc[t,r])
                if w>0: edge_table.append({'tool':t,'raw_material':r,'weight':w})
        pd.DataFrame(edge_table).to_csv(os.path.join(EDGES,f'{prefix}_phase_{int(ph)}_edges.csv'), index=False)
        rows.append(dict(Phase=int(ph), n_artifacts=n, tool_nodes=tn, raw_material_nodes=rn, total_nodes=tn+rn,
                         bipartite_edges=obs, possible_bipartite_edges=poss, bipartite_density=dens,
                         edge_entropy=ent, edge_evenness=even, mean_tool_degree=float(np.mean(tool_deg)),
                         sd_tool_degree=float(np.std(tool_deg,ddof=1)) if tn>1 else np.nan,
                         mean_raw_degree=float(np.mean(rm_deg)), sd_raw_degree=float(np.std(rm_deg,ddof=1)) if rn>1 else np.nan,
                         mean_tool_strength=float(np.mean(tool_strength)), mean_raw_strength=float(np.mean(rm_strength)),
                         tool_projection_edges=proj_edges, possible_tool_projection_edges=proj_poss,
                         tool_projection_density=proj_dens, tool_projection_avg_clustering=avg_clust))
        # null: permute raw labels among artefacts within phase; preserves tool and raw frequencies.
        tool_vals=g[tool_col].to_numpy(); rm_vals=g[rm_col].to_numpy()
        null_edges=[]; null_dens=[]; null_even=[]
        for i in range(n_null):
            perm=rng.permutation(rm_vals)
            # tuple unique combinations and counts
            counter=Counter(zip(tool_vals,perm))
            e=len(counter); null_edges.append(e); null_dens.append(e/poss if poss else np.nan)
            entr=shannon_entropy(counter.values()); null_even.append(entr/math.log(e) if e>1 else np.nan)
        null_edges=np.array(null_edges); null_dens=np.array(null_dens); null_even=np.array(null_even)
        null_rows.append(dict(Phase=int(ph), observed_edges=obs, null_mean_edges=float(null_edges.mean()), null_sd_edges=float(null_edges.std(ddof=1)),
                              edge_z=float((obs-null_edges.mean())/null_edges.std(ddof=1)) if null_edges.std(ddof=1)>0 else np.nan,
                              p_less_or_equal=float((np.sum(null_edges<=obs)+1)/(n_null+1)),
                              p_greater_or_equal=float((np.sum(null_edges>=obs)+1)/(n_null+1)),
                              observed_density=dens, null_mean_density=float(np.nanmean(null_dens)), null_sd_density=float(np.nanstd(null_dens,ddof=1)),
                              density_z=float((dens-np.nanmean(null_dens))/np.nanstd(null_dens,ddof=1)) if np.nanstd(null_dens,ddof=1)>0 else np.nan,
                              observed_evenness=even, null_mean_evenness=float(np.nanmean(null_even)),
                              evenness_z=float((even-np.nanmean(null_even))/np.nanstd(null_even,ddof=1)) if np.nanstd(null_even,ddof=1)>0 else np.nan))
    return pd.DataFrame(rows).sort_values('Phase'), pd.DataFrame(null_rows).sort_values('Phase')

metrics_grouped, null_grouped=bipartite_metrics(df, 'TOOL_CLASS','RM_GROUP', n_null=2000, seed=1, prefix='toolclass_rmgroup')
metrics_fine, null_fine=bipartite_metrics(df, 'TOOL_CLASS','RMTYPE', n_null=2000, seed=2, prefix='toolclass_rmfine')
metrics_type_grouped, null_type_grouped=bipartite_metrics(df, 'TYPE_BROAD','RM_GROUP', n_null=2000, seed=3, prefix='broadtype_rmgroup')
metrics_grouped.to_csv(os.path.join(OUT,'bipartite_metrics_toolclass_by_rawgroup.csv'), index=False)
null_grouped.to_csv(os.path.join(OUT,'null_model_toolclass_by_rawgroup.csv'), index=False)
metrics_fine.to_csv(os.path.join(OUT,'bipartite_metrics_toolclass_by_fine_raw_material.csv'), index=False)
null_fine.to_csv(os.path.join(OUT,'null_model_toolclass_by_fine_raw_material.csv'), index=False)
metrics_type_grouped.to_csv(os.path.join(OUT,'bipartite_metrics_broadtype_by_rawgroup.csv'), index=False)
null_type_grouped.to_csv(os.path.join(OUT,'null_model_broadtype_by_rawgroup.csv'), index=False)

# ---------- multi-attribute feature network ----------
def multi_metrics(dat, n_null=500, seed=4):
    rng=np.random.default_rng(seed)
    domains={'tool':'TOOL_CLASS','raw':'RM_GROUP','platform_prep':'PLATPREP','platform_type':'PLATTYPE_CLEAN','termination':'TERMINAT','reduction':'REDUCTION_BIN_NONNONE','sdi':'SDI_BIN_NONNONE'}
    rows=[]; null_rows=[]
    for ph,g in dat.groupby('Phase'):
        arrays={d:g[c].to_numpy(dtype=object) for d,c in domains.items()}
        # observed nodes by domain
        nodes_by_domain={d:set([v for v in vals if not pd.isna(v)]) for d,vals in arrays.items()}
        edge_counts=Counter()
        for i in range(len(g)):
            attrs=[]
            for d,vals in arrays.items():
                v=vals[i]
                if pd.isna(v): continue
                attrs.append((d,f'{d}:{v}'))
            for (d1,n1),(d2,n2) in itertools.combinations(attrs,2):
                if d1!=d2:
                    edge_counts[tuple(sorted((n1,n2)))] += 1
        possible=sum(len(nodes_by_domain[d1])*len(nodes_by_domain[d2]) for d1,d2 in itertools.combinations(domains.keys(),2))
        obs=len(edge_counts); dens=obs/possible if possible else np.nan
        ent=shannon_entropy(edge_counts.values()); even=ent/math.log(obs) if obs>1 else np.nan
        nodes=set([n for edge in edge_counts for n in edge])
        G=nx.Graph(); G.add_nodes_from(nodes)
        for (n1,n2),w in edge_counts.items(): G.add_edge(n1,n2,weight=w)
        mean_degree=float(np.mean([d for _,d in G.degree()])) if G.number_of_nodes()>0 else np.nan
        mean_strength=float(np.mean([sum(dd.get('weight',1) for _,_,dd in G.edges(n,data=True)) for n in G.nodes()])) if G.number_of_nodes()>0 else np.nan
        avg_clust=nx.average_clustering(G) if G.number_of_nodes()>1 else np.nan
        # save edges
        pd.DataFrame([{'node1':e[0],'node2':e[1],'weight':w} for e,w in edge_counts.items()]).to_csv(os.path.join(EDGES,f'multiattribute_phase_{int(ph)}_edges.csv'), index=False)
        row=dict(Phase=int(ph), n_artifacts=len(g), nodes=len(nodes), edges=obs, possible_cross_domain_edges=possible,
                 density=dens, edge_entropy=ent, edge_evenness=even, mean_degree=mean_degree, mean_strength=mean_strength, avg_clustering=avg_clust)
        for d in domains.keys(): row[f'nodes_{d}']=len(nodes_by_domain[d])
        rows.append(row)
        # null by shuffling each domain independently, preserving missingness and frequencies.
        null_edges=[]; null_dens=[]; null_even=[]
        keys=list(domains.keys())
        for it in range(n_null):
            rand={d:rng.permutation(arrays[d]) for d in keys}
            nd={d:set([v for v in rand[d] if not pd.isna(v)]) for d in keys}
            ec=Counter()
            for i in range(len(g)):
                attrs=[]
                for d in keys:
                    v=rand[d][i]
                    if pd.isna(v): continue
                    attrs.append((d,f'{d}:{v}'))
                for (d1,n1),(d2,n2) in itertools.combinations(attrs,2):
                    if d1!=d2: ec[tuple(sorted((n1,n2)))] += 1
            poss=sum(len(nd[d1])*len(nd[d2]) for d1,d2 in itertools.combinations(keys,2))
            e=len(ec); null_edges.append(e); null_dens.append(e/poss if poss else np.nan)
            entr=shannon_entropy(ec.values()); null_even.append(entr/math.log(e) if e>1 else np.nan)
        null_edges=np.array(null_edges); null_dens=np.array(null_dens); null_even=np.array(null_even)
        null_rows.append(dict(Phase=int(ph), observed_edges=obs, null_mean_edges=float(null_edges.mean()), null_sd_edges=float(null_edges.std(ddof=1)),
                              edge_z=float((obs-null_edges.mean())/null_edges.std(ddof=1)) if null_edges.std(ddof=1)>0 else np.nan,
                              p_less_or_equal=float((np.sum(null_edges<=obs)+1)/(n_null+1)),
                              observed_density=dens, null_mean_density=float(np.nanmean(null_dens)), null_sd_density=float(np.nanstd(null_dens,ddof=1)),
                              density_z=float((dens-np.nanmean(null_dens))/np.nanstd(null_dens,ddof=1)) if np.nanstd(null_dens,ddof=1)>0 else np.nan,
                              observed_evenness=even, null_mean_evenness=float(np.nanmean(null_even)),
                              evenness_z=float((even-np.nanmean(null_even))/np.nanstd(null_even,ddof=1)) if np.nanstd(null_even,ddof=1)>0 else np.nan))
    return pd.DataFrame(rows).sort_values('Phase'), pd.DataFrame(null_rows).sort_values('Phase')

mmetrics, mnull=multi_metrics(df, n_null=500)
mmetrics.to_csv(os.path.join(OUT,'multiattribute_feature_network_metrics.csv'), index=False)
mnull.to_csv(os.path.join(OUT,'multiattribute_feature_network_null_model.csv'), index=False)

# ---------- reduction and profile summaries ----------
def summarise_phase(dat):
    rows=[]
    for ph,g in dat.groupby('Phase'):
        counts=g['ARTEFACT_PROFILE'].value_counts()
        sh=shannon_entropy(counts.values)
        rows.append(dict(Phase=int(ph), n_artifacts=len(g),
                         unique_profiles=int(counts.size), profile_shannon=sh, profile_evenness=sh/math.log(counts.size) if counts.size>1 else np.nan,
                         mean_reduction_all=float(g['REDUCTION_COMP_ALL'].mean()), median_reduction_all=float(g['REDUCTION_COMP_ALL'].median()),
                         pct_reduction_present=float((g['REDUCTION_COMP_ALL']>0).mean()*100),
                         n_reduction_present=int((g['REDUCTION_COMP_ALL']>0).sum()),
                         mean_reduction_present=float(g.loc[g['REDUCTION_COMP_ALL']>0,'REDUCTION_COMP_ALL'].mean()) if (g['REDUCTION_COMP_ALL']>0).any() else np.nan,
                         median_reduction_present=float(g.loc[g['REDUCTION_COMP_ALL']>0,'REDUCTION_COMP_ALL'].median()) if (g['REDUCTION_COMP_ALL']>0).any() else np.nan,
                         mean_SDI_all=float(g['SDI_filled'].mean()), pct_SDI_present=float((g['SDI_filled']>0).mean()*100)))
    return pd.DataFrame(rows).sort_values('Phase')
phase_summary=summarise_phase(df)
phase_summary.to_csv(os.path.join(OUT,'phase_profile_and_reduction_summary.csv'), index=False)

# Kruskal-Wallis and pairwise on reduction present + all (all has many zeros)
def kruskal_and_pairwise(dat, col, filt=None, prefix='reduction'):
    dd=dat.copy()
    if filt is not None:
        dd=dd.query(filt)
    groups=[g[col].dropna().values for ph,g in dd.groupby('Phase') if len(g[col].dropna())>0]
    phases=[int(ph) for ph,g in dd.groupby('Phase') if len(g[col].dropna())>0]
    kw=stats.kruskal(*groups) if len(groups)>1 else (np.nan,np.nan)
    pair=[]
    for p1,p2 in itertools.combinations(phases,2):
        x=dd.loc[dd['Phase']==p1,col].dropna().values; y=dd.loc[dd['Phase']==p2,col].dropna().values
        if len(x)>0 and len(y)>0:
            u,p=stats.mannwhitneyu(x,y,alternative='two-sided')
            pair.append({'phase1':p1,'phase2':p2,'U':u,'p_uncorrected':p})
    pdf=pd.DataFrame(pair)
    if len(pdf)>0:
        pdf['p_bonferroni']=(pdf['p_uncorrected']*len(pdf)).clip(upper=1)
    pd.DataFrame([{'metric':col,'filter':filt or 'none','H':kw.statistic if hasattr(kw,'statistic') else kw[0], 'p':kw.pvalue if hasattr(kw,'pvalue') else kw[1], 'phases':','.join(map(str,phases))}]).to_csv(os.path.join(OUT,f'{prefix}_kruskal.csv'),index=False)
    pdf.to_csv(os.path.join(OUT,f'{prefix}_pairwise_mannwhitney.csv'),index=False)
    return pdf
kruskal_and_pairwise(df,'REDUCTION_COMP_ALL', prefix='reduction_all')
kruskal_and_pairwise(df[df['REDUCTION_COMP_ALL']>0],'REDUCTION_COMP_ALL', prefix='reduction_present')

# ---------- rarefaction controls for unequal sample size ----------
def compute_small_metrics(sample):
    d=sample.dropna(subset=['TOOL_CLASS','RM_GROUP'])
    ct=d.groupby(['TOOL_CLASS','RM_GROUP']).size().unstack(fill_value=0)
    tn=ct.shape[0]; rn=ct.shape[1]
    e=int((ct.values>0).sum()); poss=tn*rn
    counts=sample['ARTEFACT_PROFILE'].value_counts()
    sh=shannon_entropy(counts.values)
    return {'tool_nodes':tn,'raw_nodes':rn,'bipartite_edges':e,'bipartite_density':e/poss if poss else np.nan,
            'unique_profiles':counts.size,'profile_shannon':sh,'mean_reduction_all':sample['REDUCTION_COMP_ALL'].mean(),
            'pct_reduction_present':(sample['REDUCTION_COMP_ALL']>0).mean()*100}

def rarefy(dat, n_iter=1000, seed=7):
    rng=np.random.default_rng(seed)
    min_n=int(dat.groupby('Phase').size().min())
    rows=[]
    for ph,g in dat.groupby('Phase'):
        idx=g.index.to_numpy()
        for it in range(n_iter):
            samp_idx=rng.choice(idx, size=min_n, replace=False)
            m=compute_small_metrics(dat.loc[samp_idx])
            m['Phase']=int(ph); m['iteration']=it; m['n_rarefied']=min_n
            rows.append(m)
    r=pd.DataFrame(rows)
    summ=[]
    for (ph),gg in r.groupby('Phase'):
        row={'Phase':int(ph),'n_rarefied':min_n}
        for col in ['tool_nodes','raw_nodes','bipartite_edges','bipartite_density','unique_profiles','profile_shannon','mean_reduction_all','pct_reduction_present']:
            row[col+'_mean']=gg[col].mean(); row[col+'_lo95']=gg[col].quantile(0.025); row[col+'_hi95']=gg[col].quantile(0.975)
        summ.append(row)
    return r, pd.DataFrame(summ).sort_values('Phase')
rare_iter, rare_summary=rarefy(df, n_iter=1000)
rare_iter.to_csv(os.path.join(OUT,'rarefaction_iterations_n160.csv'), index=False)
rare_summary.to_csv(os.path.join(OUT,'rarefaction_summary_n160.csv'), index=False)

# ---------- correlations and dry/wet tests ----------
dry_phases={2,4,7}
combined=metrics_grouped.merge(phase_summary, on=['Phase','n_artifacts'], how='left', suffixes=('','_summary'))
combined=combined.merge(mmetrics[['Phase','nodes','edges','density','edge_evenness','avg_clustering']].rename(columns={'nodes':'multi_nodes','edges':'multi_edges','density':'multi_density','edge_evenness':'multi_evenness','avg_clustering':'multi_avg_clustering'}), on='Phase', how='left')
combined['dry_phase']=combined['Phase'].apply(lambda p: 1 if p in dry_phases else 0)
combined.to_csv(os.path.join(OUT,'combined_phase_metrics.csv'), index=False)
# correlations among selected variables
corr_rows=[]
cols=['n_artifacts','tool_nodes','raw_material_nodes','bipartite_edges','bipartite_density','edge_evenness','tool_projection_density','unique_profiles','profile_shannon','mean_reduction_all','pct_reduction_present','mean_reduction_present','multi_nodes','multi_edges','multi_density','dry_phase']
for x,y in itertools.combinations(cols,2):
    xx=combined[x]; yy=combined[y]
    mask=xx.notna() & yy.notna()
    if mask.sum()>=3:
        pr=stats.pearsonr(xx[mask],yy[mask])
        sr=stats.spearmanr(xx[mask],yy[mask])
        corr_rows.append({'x':x,'y':y,'n':int(mask.sum()),'pearson_r':pr.statistic,'pearson_p':pr.pvalue,'spearman_rho':sr.statistic,'spearman_p':sr.pvalue})
pd.DataFrame(corr_rows).to_csv(os.path.join(OUT,'phase_metric_correlations.csv'), index=False)
# dry/wet descriptive tests (Mann-Whitney) for metrics
mw=[]
for col in cols:
    if col=='dry_phase': continue
    dry=combined.loc[combined['dry_phase']==1,col].dropna(); wet=combined.loc[combined['dry_phase']==0,col].dropna()
    if len(dry)>0 and len(wet)>0:
        try:
            u,p=stats.mannwhitneyu(dry,wet,alternative='two-sided')
        except Exception:
            u,p=np.nan,np.nan
        mw.append({'metric':col,'dry_mean':dry.mean(),'wet_mean':wet.mean(),'dry_median':dry.median(),'wet_median':wet.median(),'U':u,'p':p,'n_dry':len(dry),'n_wet':len(wet)})
pd.DataFrame(mw).to_csv(os.path.join(OUT,'dry_wet_descriptive_tests.csv'), index=False)

# ---------- figures ----------
def savefig(name):
    plt.tight_layout()
    plt.savefig(os.path.join(FIG,name+'.png'), dpi=300, bbox_inches='tight')
    plt.savefig(os.path.join(FIG,name+'.tif'), dpi=600, bbox_inches='tight')
    plt.close()

ph=metrics_grouped['Phase']
plt.figure(figsize=(6.5,4.0))
plt.plot(ph, metrics_grouped['tool_nodes'], marker='o', label='Tool-class nodes')
plt.plot(ph, metrics_grouped['raw_material_nodes'], marker='o', label='Raw-material nodes')
plt.plot(ph, metrics_grouped['bipartite_edges'], marker='o', label='Tool–raw-material edges')
plt.xlabel('Phase')
plt.ylabel('Count')
plt.title('Individual artefact tool–raw-material network richness')
plt.legend(frameon=False)
savefig('fig1_individual_bipartite_richness_edges')

plt.figure(figsize=(6.5,4.0))
plt.plot(ph, metrics_grouped['bipartite_density'], marker='o', label='Bipartite density')
plt.plot(ph, metrics_grouped['tool_projection_density'], marker='o', label='Tool-projection density')
plt.xlabel('Phase')
plt.ylabel('Density')
plt.title('Network density after controlling for possible connections')
plt.legend(frameon=False)
savefig('fig2_individual_network_density')

plt.figure(figsize=(6.5,4.0))
plt.scatter(metrics_grouped['total_nodes'], metrics_grouped['bipartite_edges'])
for _,r in metrics_grouped.iterrows():
    plt.annotate(str(int(r['Phase'])), (r['total_nodes'], r['bipartite_edges']), textcoords='offset points', xytext=(5,5))
plt.xlabel('Total nodes')
plt.ylabel('Observed bipartite edges')
plt.title('Observed edges remain strongly related to node richness')
savefig('fig3_nodes_vs_edges')

plt.figure(figsize=(6.5,4.0))
plt.plot(phase_summary['Phase'], phase_summary['unique_profiles'], marker='o', label='Unique artefact profiles')
plt.plot(phase_summary['Phase'], phase_summary['profile_shannon'], marker='o', label='Profile Shannon diversity')
plt.xlabel('Phase')
plt.ylabel('Value')
plt.title('Individual artefact profile diversity')
plt.legend(frameon=False)
savefig('fig4_individual_profile_diversity')

plt.figure(figsize=(6.5,4.0))
plt.plot(phase_summary['Phase'], phase_summary['mean_reduction_all'], marker='o', label='Mean reduction index, all artefacts')
plt.plot(phase_summary['Phase'], phase_summary['mean_reduction_present'], marker='o', label='Mean reduction index, reduced artefacts only')
plt.xlabel('Phase')
plt.ylabel('Composite reduction index')
plt.title('Reduction intensity in complete artefacts')
plt.legend(frameon=False)
savefig('fig5_reduction_intensity_complete_artefacts')

plt.figure(figsize=(6.5,4.0))
plt.plot(mmetrics['Phase'], mmetrics['nodes'], marker='o', label='Feature nodes')
plt.plot(mmetrics['Phase'], mmetrics['edges'], marker='o', label='Feature edges')
plt.xlabel('Phase')
plt.ylabel('Count')
plt.title('Multi-attribute feature-network size')
plt.legend(frameon=False)
savefig('fig6_multiattribute_nodes_edges')

plt.figure(figsize=(6.5,4.0))
plt.plot(mmetrics['Phase'], mmetrics['density'], marker='o', label='Feature-network density')
plt.plot(mmetrics['Phase'], mmetrics['edge_evenness'], marker='o', label='Feature edge evenness')
plt.xlabel('Phase')
plt.ylabel('Value')
plt.title('Multi-attribute feature-network density and evenness')
plt.legend(frameon=False)
savefig('fig7_multiattribute_density_evenness')

# rarefaction figure with error bars
plt.figure(figsize=(6.5,4.0))
x=rare_summary['Phase']
y=rare_summary['tool_nodes_mean']
yerr=[y-rare_summary['tool_nodes_lo95'], rare_summary['tool_nodes_hi95']-y]
plt.errorbar(x, y, yerr=yerr, marker='o', capsize=3, label='Rarefied tool richness')
y2=rare_summary['unique_profiles_mean']
yerr2=[y2-rare_summary['unique_profiles_lo95'], rare_summary['unique_profiles_hi95']-y2]
plt.errorbar(x, y2, yerr=yerr2, marker='o', capsize=3, label='Rarefied profile richness')
plt.xlabel('Phase')
plt.ylabel('Rarefied count (n=160 artefacts per phase)')
plt.title('Sample-size controlled richness')
plt.legend(frameon=False)
savefig('fig8_rarefied_richness')

plt.figure(figsize=(6.5,4.0))
y=rare_summary['bipartite_density_mean']
yerr=[y-rare_summary['bipartite_density_lo95'], rare_summary['bipartite_density_hi95']-y]
plt.errorbar(x, y, yerr=yerr, marker='o', capsize=3, label='Rarefied bipartite density')
y2=rare_summary['profile_shannon_mean']
yerr2=[y2-rare_summary['profile_shannon_lo95'], rare_summary['profile_shannon_hi95']-y2]
plt.errorbar(x, y2, yerr=yerr2, marker='o', capsize=3, label='Rarefied profile Shannon')
plt.xlabel('Phase')
plt.ylabel('Rarefied value (n=160 artefacts per phase)')
plt.title('Sample-size controlled density and profile diversity')
plt.legend(frameon=False)
savefig('fig9_rarefied_density_profile_shannon')

# README summary
# Important correlations
nodes_edges=stats.pearsonr(metrics_grouped['total_nodes'], metrics_grouped['bipartite_edges'])
spe_nodes_edges=stats.spearmanr(metrics_grouped['total_nodes'], metrics_grouped['bipartite_edges'])
readme=f'''Complete artefact network analysis for Madjedbebe
Input: {os.path.basename(INPUT)}
Rows analysed: {len(df)} complete artefacts in Phases 2-7. Phase 1 was excluded to match the manuscript's occupational analysis.

Main primary network: TOOL_CLASS (TYPOLOGY where present, otherwise TYPE) x grouped raw material (RM_GROUP).
Raw-material grouping is defined in the script and preserves the main analytical classes: Quartz, Quartzite, Silcrete, Chert/chalcedony, Dolerite/volcanic, Sandstone, Tuff/mudstone, Fine-grained stone, Glass, Other/unknown lithology.
PLATTYPE code 95 was treated as missing/undetermined.

Key results:
1. Richness remains highest in Phases 2 and 4. In the primary network, Phase 2 has {int(metrics_grouped.loc[metrics_grouped.Phase==2,'tool_nodes'].iloc[0])} tool nodes and {int(metrics_grouped.loc[metrics_grouped.Phase==2,'bipartite_edges'].iloc[0])} tool-material edges; Phase 4 has {int(metrics_grouped.loc[metrics_grouped.Phase==4,'tool_nodes'].iloc[0])} tool nodes and {int(metrics_grouped.loc[metrics_grouped.Phase==4,'bipartite_edges'].iloc[0])} edges.
2. Raw edge counts are still strongly coupled with node richness: Pearson r={nodes_edges.statistic:.3f}, p={nodes_edges.pvalue:.4g}; Spearman rho={spe_nodes_edges.statistic:.3f}, p={spe_nodes_edges.pvalue:.4g}. Therefore, raw node/edge counts should be treated as richness/system-size measures, not as independent proof of integration.
3. Density/connectance separates from richness. Phase 7 has the highest primary bipartite density ({float(metrics_grouped.loc[metrics_grouped.Phase==7,'bipartite_density'].iloc[0]):.3f}) despite fewer nodes, while Phases 2 and 4 have larger, richer but less dense networks.
4. Null models that permute raw-material labels within phases show that observed tool-material edge counts are lower than expected under random association in all phases, especially Phases 2 and 4. This supports a structured, non-random relationship between technological classes and raw materials rather than random mixing.
5. Individual artefact profile diversity reinforces the richness result. Unique techno-material profiles are highest in Phase 2 and Phase 4 in the full data, and the rarefaction analysis at n=160 artefacts per phase shows these phases still retain high tool/profile richness after sample-size control.
6. Reduction intensity remains strongest in Phase 7. The complete artefact data therefore strengthens the interpretation that Phase 7 is not simply richer; it is denser and much more reduction-intensive.

Interpretive conclusion:
The individual artefact data strengthen the manuscript if the argument distinguishes three different dimensions of complexity: richness, integration/density, and reduction investment. Phases 2 and 4 are strongest for technological and raw-material richness/profile diversity. Phase 7 is strongest for density/connectance and reduction intensity. The data do not support a simple claim that all dry phases are uniformly more integrated, but they do support a more nuanced claim that complexity was expressed differently under different mobility/provisioning conditions.
'''
with open(os.path.join(OUT,'README_summary.txt'),'w') as f: f.write(readme)

# Zip package
ZIP='/mnt/data/complete_artefact_network_analysis_package.zip'
with zipfile.ZipFile(ZIP,'w',zipfile.ZIP_DEFLATED) as z:
    for root,dirs,files in os.walk(OUT):
        for file in files:
            fp=os.path.join(root,file)
            z.write(fp, os.path.relpath(fp, os.path.dirname(OUT)))
    z.write('/mnt/data/run_complete_artefact_network_analysis.py','run_complete_artefact_network_analysis.py')
print('DONE')
print(ZIP)
print(metrics_grouped.round(3).to_string(index=False))
print(phase_summary.round(3).to_string(index=False))
print(rare_summary.round(3).to_string(index=False))
